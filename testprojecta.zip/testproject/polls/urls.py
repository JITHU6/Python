from django.urls import path,re_path
from . import views


urlpatterns=[
    path('signup',views.signup,name='signup'),
    path('index/',views.index,name='index'),
    path('login',views.Login,name='login'),
    path('ajax/savedata',views.addQuestion,name='savedata'),
    path('logout',views.logout_view,name='logout'),
    re_path(r'^vote/(?P<qid>\d+)/$',views.vote,name='votea'),
    path('vote/',views.vote,name='vote'),
    path('ajax/incrementcount',views.incrementcount,name='incrementcount'),
    path('ajax/incrementcountcheckbox',views.incrementcountcheckbox,name='incrementcountcheckbox'),
    path('votecountss',views.votecounts,name='votecounts'),
    # path('insertdata',views.InsertData,name='insertdata')
]