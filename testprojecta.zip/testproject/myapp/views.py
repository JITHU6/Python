from django.shortcuts import render
from django.http import HttpResponse
from myapp.models import Dreamreal
import datetime

# Create your views here.
def hello(request):
    to=datetime.datetime.now().date()
    daysOfWeek = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    return render(request,"hello.html",{"today":to,"days":daysOfWeek})
