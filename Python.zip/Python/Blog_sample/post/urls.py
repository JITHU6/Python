from . import views
from django.conf.urls import url, include

urlpatterns = [
    url(r'^$', views.Index, name='index'),
    url(r'^details/(?P<id>\d+)/$', views.details)
]
