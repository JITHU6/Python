
$(document).ready(function() {
    $("input[type='radio']").click(function() {
        if($(this).val()=="singleselection")
        {
            $("#showtextfield").show();
        }
        else
        {
                $("#showtextfield").hide(); 
        } 
    });
});
