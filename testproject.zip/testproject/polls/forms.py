from django import forms
from .models import Person
from django.core.validators import MaxValueValidator,MinValueValidator
class UserForm(forms.Form):
    email= forms.EmailField(label='Your Email')
    password= forms.CharField(label='Your name',widget=(forms.PasswordInput), max_length=100)
    def clean_email(self):
        email=self.cleaned_data.get('email')
        # if Person.email:
        #     raise forms.ValidationError("email not registered")
        return email
    def clean_password(self):
        password=self.cleaned_data.get('password')
        if len(password) <= 0 :
            self.errors['password']=self.error_class(['enter a valid password'])
        return password

class CreateUser(forms.Form):
    name=forms.CharField(label='Your name', max_length=100)
    email=forms.CharField(widget=(forms.TextInput))
    password=forms.CharField(label='Password',widget=(forms.PasswordInput),max_length=250)
    password2 = forms.CharField(label='Password confirmation', widget=(forms.PasswordInput))

    class Meta:
        model=Person
        fields=('name','email','password','password2')

    def clean_name(self):
        name=self.cleaned_data.get('name')
        if len(name) < 5 :
            self.errors['name']=self.error_class(['minimum 5 charecter required'])
        return name
    def clean_email(self):
        email=self.cleaned_data.get('email')
        qs=Person.objects.filter(email=email)
        if qs.exists():
            raise forms.ValidationError("email is taken")
        return email
    def clean_password(self):
        passworda=self.cleaned_data.get('password')
        
        if len(passworda) <= 1 :  
            self.errors['password']=self.error_class(['minimum 2 charecter required'])
        return passworda
    def clean_password2(self):
        password1=self.cleaned_data.get('password')  
        password2=self.cleaned_data.get('password2')
        if password1 and password2 and password1!=password2:
            raise forms.ValidationError("Password not matching")
        return password1
class CreateQuestion(forms.Form):
    CHOICES=[('singleselection','singleselection '),
         ('multipleselection','multipleselection')]
    question=forms.CharField(label='Enter your Question',max_length=250)
    answermode=forms.ChoiceField(label="select option",choices=CHOICES,widget=(forms.RadioSelect))

    def clean_question(self):
       
        question=self.cleaned_data.get('question')
        
        if len(question) < 0:
            self.errors['question']=self.error_class(['minimum 5 charecter required'])
        return question   
    # def clean_answermode(self):
    #     answermode=self.cleaned_data.get('answermode')
        
    #     return answermode


   
        
        
