from django.db import models

# Create your models here.
class Person(models.Model):
    
    name=models.CharField(max_length=250)
    email=models.EmailField(blank=False)
    password=models.CharField(max_length=50)
class Question(models.Model):
    quest_id=models.AutoField(primary_key=True)
    author=models.ForeignKey(Person,on_delete=models.CASCADE)
    question=models.CharField(max_length=250)
    ansermode=models.CharField(max_length=250)
    post_date=models.DateTimeField('date published')
    class Meta:
        get_latest_by = ['quest_id']
    def __str__(self):
        return self.question    
class Choice(models.Model):
    question_id=models.ForeignKey(Question, on_delete=models.CASCADE)
    choice=models.TextField(max_length=250)
    vote=models.IntegerField(default=0)
    class Meta:
        get_latest_by = ['quest_id']
        
        
    

