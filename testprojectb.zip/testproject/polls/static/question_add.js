    
$('#submita').click(function (){
    var choice=[];

    var question=$('#id_question').val();
    var answermode=$("input[name='answermode']:checked").val();
    // var count=$("#count").val();
    // var choice=$("#textbox1").val();
    for(var i=0;i<5;++i){
        var k = i+1;
        choice[i]=$("#textbox"+k).val();
    }
    
    
    
    var token = '{{csrf_token}}';
    $.ajax({
        headers: { "X-CSRFToken": token },
        type: "POST",
        url: 'ajax/savedata',
        data: {

          'question': question,
          'answermode':answermode,
          'choicea':choice
        },
        dataType: 'json',
        
        
        success: function (data) {
            console.log(data)
            alert("A user with this username already exists.");
          
        }
    });

});


$(document).ready(function(){
    var count=2;

    $("#add").click(function(){
        if(count>10){
            alert("only 10 options allowed");
            return false;
        }
        var newtextboxdiv=$(document.createElement('div')).attr("id",'textboxdiv'+count);
        newtextboxdiv.after().html('<label>TextBox#'+count+'</label><input type="text" name="textbox'+count+'" id="textbox'+ count +'"><br>');
        newtextboxdiv.appendTo("#textboxgroupdiv");
        $("#countdiv").after().html('<input type="text" name="count" id="count" value="'+count+'"')
        count++;
    });
    $("#remove").click(function(){
        if(count==1){
            alert("no more textfield to remove");
            return false;
        }
        count--;
        $("#textboxdiv"+ count).remove();
    });
    
});
