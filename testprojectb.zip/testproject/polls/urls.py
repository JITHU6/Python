from django.urls import path,re_path
from . import views

app_name='polls'
urlpatterns=[
    path('',views.signup,name='signup'),
    
    path('login',views.Login,name='login'),
    path('ajax/savedata',views.addQuestion,name='savedata'),
    path('logout',views.logout_view,name='userlogout'),
    path('vote/',views.voteerror,name='vote'),
    re_path(r'^vote/(?P<qid>\d+)/$',views.vote,name='vote'),
    path('incrementcount',views.incrementcount,name='incrementcount'),
    path('incrementcountcheckbox',views.incrementcountcheckbox,name='incrementcountcheckbox'),
    path('votecount',views.votecounts,name='votecount'),
    # path('insertdata',views.InsertData,name='insertdata')
]