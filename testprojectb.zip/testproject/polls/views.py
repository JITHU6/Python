from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import CreateView
from .models import Person,Question,Choice
from .forms import UserForm,CreateUser,CreateQuestion
from django.views.generic.edit import FormView 
from django.forms import forms
from django.contrib import messages
from django.contrib.auth import logout
from django.shortcuts import redirect
from datetime import datetime, timedelta
from django.http import JsonResponse
from django.utils import timezone
import json
from django.core import serializers
from django.db.models import F

# Create your views here.

   
    
# class PersonCreateView(FormView):
#     template_name='person_form.html'
#     form_class=CreateUser
#     success_url = '/thanks/'
#     def is_valid(self,form):
#         return super.form_valid(form)

def index(request):
    
    return render(request,"polls/base.html")
def signup(request):
    if request.method == 'POST':   
        form=CreateUser(request.POST)
        if form.is_valid():
            a=Person()
            a.name=form.cleaned_data.get("name")
            a.email=form.cleaned_data.get("email")
            a.password=form.cleaned_data.get("password")   
            a.save()  
            messages.success(request, 'Account Created')   
                          
            return redirect('login')
        else:
             messages.success(request, 'SignUp Unsuccess') 

    else:
        form=CreateUser()
       
    # return render(request,"polls/person_form.html",{"form":form})
    return render(request,"polls/person_form.html",{"form":form})   
def Login(request):  
   
    if request.method == 'POST':
        form=UserForm(request.POST)
        if form.is_valid():           
            email=form.cleaned_data.get('email')
            password=form.cleaned_data.get('password')
            p=Person.objects.get(email=email)           
            if p.email==email and p.password == password :               
                name=p.name
                userid=p.id
                request.session['username'] = name
                request.session['userid'] = userid              
                return  render(request,"polls/admin/admin_addquestion.html",{"form":CreateQuestion,"name":name,"userid":request.session['userid']})
            else:              
                messages.success(request, 'Incorrect username or password') 
                return redirect('login')
        else:
             messages.success(request, 'Login Unsuccess') 
    else: 
        form=UserForm()       
    return render(request,"polls/login.html",{"form":form})   
def addQuestion(request):
    if request.method == 'POST':      
        form=CreateQuestion(request.POST)                 
        if form.is_valid():                               
            q=Question()
            q.question=form.cleaned_data.get('question')
            q.post_date=timezone.now()
            q.author_id=request.session.get('userid')
            q.ansermode=request.POST['answermode']
            q.save()
            a=request.POST.getlist('choicea[]')
            for aa in a:
                c=Choice()
                c.choice=aa 
                c.question_id=Question.objects.latest()
                c.save()            
            messages.success(request, 'Question Added')           
        else:
            form=CreateQuestion()    
            messages.success(request, 'Data not saved')                   
    return render(request,"polls/admin/admin_addquestion.html",{"form":form})   

def logout_view(request):
    logout(request)
    return redirect('signup')
def vote(request,qid):
    #selecting questing and choice
    question=Question.objects.filter(quest_id=qid)
    questionid=Question.objects.get(quest_id=qid)
    choicea=Choice.objects.filter(question_id_id=questionid.quest_id)
    
    data = serializers.serialize('json', choicea)
    
    jsondata=json.loads(data) 
    
    # a=jsondata[0] 
    # b=a['fields']
    # c=b["choice"]   
    # jsondataa=json.loads(c)
    return render(request,'polls/vote/vote.html',{"question":questionid,"choice":choicea})
def voteerror(request):
    #selecting questing and choice
    
    return HttpResponse("provide a question id")
def incrementcount(request):
    if request.method == 'POST':       
        choiceid=request.POST['vote']
        
        print(choiceid)
        Choice.objects.filter(id = choiceid).update(vote=F('vote') + 1)
    return HttpResponse("success")
def incrementcountcheckbox(request):
    if request.method == 'POST':       
        choiceid=request.POST.get('')       
        for a in choiceid:
            Choice.objects.filter(id = a).update(vote=F('vote') + 1) 
             
    return HttpResponse("success")
def votecounts(request):
    question=Question.objects.all()
    if request.method=="POST":
        qid=request.POST.get('cars')
        responseData=Choice.objects.filter(question_id_id=qid)
       
        data = serializers.serialize('json', responseData)
        print(data)
        # return JsonResponse({"data":data})
        return render(request,"polls/admin/votecounts.html",{"question":question,"choice":responseData})
    return render(request,"polls/admin/votecounts.html",{"question":question})