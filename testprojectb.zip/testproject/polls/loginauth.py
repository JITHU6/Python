from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import redirect,render
from django.urls import reverse
from .urls import urlpatterns
def simple_middleware(get_response):
    # One-time configuration and initialization.

    def middleware(request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.
        if request.session.get('userid', False):
             
            return reverse('login')
        
        request.session['userid'] = True
        return HttpResponse('Thanks for your comment!')
       
        
        response = get_response(request)

        # Code to be executed for each request/response after
        # the view is called.

        return response

    return middleware